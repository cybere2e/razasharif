# OAuth 2.0 Grant Flow Tester
This application is a tool to test different OAuth 2.0 grant flows with a given IDP.

## Steps to run
1. Clone the repository or download `oauth2-grant-flow-tester`.
2. **[Optional]** Configure the OAuth 2.0 authorize and token endpoint of the IDP in `app.env`file.
```
**Note** : You can configure this while running the CLI tool with `--authorize-endpoint` and `--token-endpoint` flags.
```
3. Run the CLI tool
```
cd oauth2-grant-flow-tester && ./oauth2-grant-flow-tester <sub-command>
```

## Tool Usage
```
Usage:
  oauth2-grant-flow-tester [flags]
  oauth2-grant-flow-tester [command]

Available Commands:
  auth-code         OAuth 2.0 Authorization Code Grant Flow
  auth-code-pkce    OAuth 2.0 Authorization Code with PKCE Grant Flow
  client-credential OAuth 2.0 Client Credential Grant Flow
  implicit          OAuth 2.0 Implicit Grant Flow
  password          OAuth 2.0 Password Grant Flow
  refresh-token     OAuth 2.0 Refresh Token Grant Flow
  completion        Generate the autocompletion script for the specified shell
  help              Help about any command

Flags:
  -a, --authorize-endpoint string   Specify the authorization endpoint of the IDP. (default "https://localhost:9443/oauth2/authorize")
  -h, --help                        help for oauth2-grant-flow-tester
  -t, --token-endpoint string       Specify the token endpoint of the IDP. (default "https://localhost:9443/oauth2/token")

Use "oauth2-grant-flow-tester [command] --help" for more information about a command.
```