package cmd

import (
	"os"

	"github.com/cybere2e/oauth2-grant-flow-tester/util"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "oauth2-grant-flow-tester",
	Short: "CLI tool to test OAuth 2.0 grant flows",
	Long:  `This application is a tool to test different OAuth 2.0 grant flows with a given IDP.`,
	// Uncomment the following line if your bare application
	// has an action associated with it:
	Run: func(cmd *cobra.Command, args []string) {
		util.SetCommandValues(cmd)
	},
}

// Execute adds all child commands to the root command and sets flags appropriately.
// This is called by main.main(). It only needs to happen once to the rootCmd.
func Execute() {
	err := rootCmd.Execute()
	if err != nil {
		os.Exit(1)
	}
}

func init() {
	rootCmd.Flags().StringP("authorize-endpoint", "a", "https://localhost:9443/oauth2/authorize", "Specify the authorization endpoint of the IDP.")
	rootCmd.Flags().StringP("token-endpoint", "t", "https://localhost:9443/oauth2/token", "Specify the token endpoint of the IDP.")
	viper.BindPFlag("authorize_endpoint", authCodeFlowCmd.PersistentFlags().Lookup("authorize-endpoint"))
	viper.BindPFlag("token_endpoint", authCodeFlowCmd.PersistentFlags().Lookup("token-endpoint"))
	cobra.OnInitialize(util.InitConfig)
}
