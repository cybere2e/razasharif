package cmd

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strings"

	"github.com/cybere2e/oauth2-grant-flow-tester/util"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

// authCodeFlowCmd represents the authCodeFlow command
var authCodeFlowCmd = &cobra.Command{
	Use:   "auth-code",
	Short: "OAuth 2.0 Authorization Code Grant Flow",
	Long: `The authorization code grant is used when an application exchanges an authorization code for an access token. 
	After the user returns to the application via the redirect URL, the application will get the authorization code from the URL and 
	use it to request an access token.`,

	Run: func(cmd *cobra.Command, args []string) {
		// Read required params for the authorization request.
		util.PromptAppCreation()
		clientId := util.PromptForClientId()
		clientSecret := util.PromptForClientSecret()
		callBackURL := util.PromptForCallbackURL()
		scopes := util.PromptForScopes()

		authorizeEndpoint := viper.GetString("authorize_endpoint")
		authorizeURL, _ := url.Parse(authorizeEndpoint)
		params := authorizeURL.Query()
		params.Add("response_type", "code")
		params.Add("client_id", clientId)
		params.Add("client_secret", clientSecret)
		params.Add("redirect_uri", callBackURL)
		params.Add("scope", scopes)
		authorizeURL.RawQuery = params.Encode()
		authorizeURLStr := authorizeURL.String()
		fmt.Print("\nAccess the following URL using a browser and login to your app using the IDP.\n\n" + authorizeURLStr + "\n\nEnter <code> parameter in the redirected URL in browser : ")
		var code string
		n, err := fmt.Scan(&code)
		if err != nil {
			log.Fatalln(err)
		}
		if n != 1 && len(strings.TrimSpace(code)) == 0 {
			panic("Invalid input from user as the authorization code.")
		}

		// Build payload string for the token request.
		payLoadParams := url.Values{}
		payLoadParams.Add("grant_type", "authorization_code")
		payLoadParams.Add("client_id", clientId)
		payLoadParams.Add("client_secret", clientSecret)
		payLoadParams.Add("code", code)
		payLoadParams.Add("redirect_uri", callBackURL)
		payloadStr := payLoadParams.Encode()
		payload := strings.NewReader(payloadStr)

		tokenEndpoint := viper.GetString("token_endpoint")
		req, _ := http.NewRequest("POST", tokenEndpoint, payload)
		req.Header.Add("content-type", "application/x-www-form-urlencoded")
		res, err := http.DefaultClient.Do(req)
		if err != nil {
			log.Fatalln(err)
		}
		defer res.Body.Close()
		body, _ := ioutil.ReadAll(res.Body)
		fmt.Println("\n\n" + string(body) + "\n\n")
	},
}

func init() {
	rootCmd.AddCommand(authCodeFlowCmd)
}
