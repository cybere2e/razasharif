package cmd

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strings"

	"github.com/cybere2e/oauth2-grant-flow-tester/util"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

// authCodePkceCmd represents the authCodePkce command
var authCodePkceCmd = &cobra.Command{
	Use:   "auth-code-pkce",
	Short: "OAuth 2.0 Authorization Code with PKCE Grant Flow",
	Long: `PKCE (RFC 7636) is an extension to the Authorization Code flow to prevent CSRF and authorization code injection attacks.
	PKCE is not a replacement for a client secret, and PKCE is recommended even if a client is using a client secret.`,
	Run: func(cmd *cobra.Command, args []string) {
		clientId := util.PromptForClientId()
		audience := util.PromptForAudience()
		callBackURL := util.PromptForCallbackURL()
		scopes := util.PromptForScopes()
		codeVerifier := util.CodeVerifier()
		codeChallenge := util.CodeChallengeS256(codeVerifier)

		authorizeEndpoint := viper.GetString("authorize_endpoint")
		authorizeURL, _ := url.Parse(authorizeEndpoint)
		params := authorizeURL.Query()
		params.Add("response_type", "code")
		params.Add("client_id", clientId)
		params.Add("audience", audience)
		params.Add("code_challenge", codeChallenge)
		params.Add("code_challenge_method", "S256")
		params.Add("redirect_uri", callBackURL)
		params.Add("scope", scopes)
		authorizeURL.RawQuery = params.Encode()
		authorizeURLStr := authorizeURL.String()
		fmt.Print("\nAccess the following URL using a browser and login to your app using the IDP.\n\n" + authorizeURLStr + "\n\nEnter <code> parameter in the redirected URL in browser : ")
		var code string
		n, err := fmt.Scan(&code)
		if err != nil {
			log.Fatalln(err)
		}
		if n != 1 && len(strings.TrimSpace(code)) == 0 {
			panic("Invalid input from user as the authorization code.")
		}

		// Build payload string for the token request.
		payLoadParams := url.Values{}
		payLoadParams.Add("grant_type", "authorization_code")
		payLoadParams.Add("client_id", clientId)
		payLoadParams.Add("code_verifier", codeVerifier)
		payLoadParams.Add("code", code)
		payLoadParams.Add("redirect_uri", callBackURL)
		payloadStr := payLoadParams.Encode()
		payload := strings.NewReader(payloadStr)

		tokenEndpoint := viper.GetString("token_endpoint")
		req, _ := http.NewRequest("POST", tokenEndpoint, payload)
		req.Header.Add("content-type", "application/x-www-form-urlencoded")
		res, err := http.DefaultClient.Do(req)
		if err != nil {
			log.Fatalln(err)
		}
		defer res.Body.Close()
		body, _ := ioutil.ReadAll(res.Body)
		fmt.Println("\n\n" + string(body) + "\n\n")
	},
}

func init() {
	rootCmd.AddCommand(authCodePkceCmd)
}
