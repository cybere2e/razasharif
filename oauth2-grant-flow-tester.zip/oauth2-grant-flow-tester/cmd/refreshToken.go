package cmd

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strings"

	"github.com/cybere2e/oauth2-grant-flow-tester/util"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

// refreshTokenCmd represents the refreshToken command
var refreshTokenCmd = &cobra.Command{
	Use:   "refresh-token",
	Short: "OAuth 2.0 Refresh Token Grant Flow",
	Long:  `The Refresh Token grant type is used by clients to exchange a refresh token for an access token when the access token has expired.`,
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Print("In order to tryout refresh_token grant flow, you need a refresh token. \nUse `./oauth-flow-tester auth-code` to get an access token with a refresh token. \nNote : Check on IDP specification for special scopes needed when requesting a access token to use refresh token grant.")
		fmt.Print("\nType `exit` to exit this flow to try authorization code flow. If you already have a refresh token type `continue` to proceed : ")
		var input string
		n, err := fmt.Scan(&input)
		if err != nil {
			log.Fatalln(err)
		}
		if n != 1 || !(strings.EqualFold("exit", input) || strings.EqualFold("continue", input)) {
			panic("Invalid user input.")
		}
		clientId := util.PromptForClientId()
		clientSecret := util.PromptForClientSecret()
		refreshToken := util.PromptForRefreshToken()

		// Build payload string for the token request.
		payLoadParams := url.Values{}
		payLoadParams.Add("grant_type", "refresh_token")
		payLoadParams.Add("client_id", clientId)
		payLoadParams.Add("client_secret", clientSecret)
		payLoadParams.Add("refresh_token", refreshToken)
		payloadStr := payLoadParams.Encode()
		payload := strings.NewReader(payloadStr)

		tokenEndpoint := viper.GetString("token_endpoint")
		req, _ := http.NewRequest("POST", tokenEndpoint, payload)
		req.Header.Add("content-type", "application/x-www-form-urlencoded")
		res, err := http.DefaultClient.Do(req)
		if err != nil {
			log.Fatalln(err)
		}
		defer res.Body.Close()
		body, _ := ioutil.ReadAll(res.Body)
		fmt.Println("\n\n" + string(body) + "\n\n")
	},
}

func init() {
	rootCmd.AddCommand(refreshTokenCmd)
}
