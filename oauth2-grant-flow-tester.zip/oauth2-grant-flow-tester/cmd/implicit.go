package cmd

import (
	"fmt"
	"net/url"

	"github.com/cybere2e/oauth2-grant-flow-tester/util"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

// implicitCmd represents the implicit command
var implicitCmd = &cobra.Command{
	Use:   "implicit",
	Short: "OAuth 2.0 Implicit Grant Flow",
	Long: `The Implicit flow was a simplified OAuth flow previously recommended for native apps and JavaScript apps where 
	the access token was returned immediately without an extra authorization code exchange step.
	Note : It is not recommended to use the implicit flow due to inherent security risks in the flow.`,
	Run: func(cmd *cobra.Command, args []string) {
		clientId := util.PromptForClientId()
		callBackURL := util.PromptForCallbackURL()
		authorizeEndpoint := viper.GetString("authorize_endpoint")
		authorizeURL, _ := url.Parse(authorizeEndpoint)
		params := authorizeURL.Query()
		params.Add("response_type", "token")
		params.Add("client_id", clientId)
		params.Add("redirect_uri", callBackURL)
		authorizeURL.RawQuery = params.Encode()
		authorizeURLStr := authorizeURL.String()
		fmt.Print("\nAccess the following URL using a browser and login to your app using the IDP.\n\n" + authorizeURLStr + "\n\nAccess token will be sent as a query parameter in the redirected URL in the browser.\n\n")
	},
}

func init() {
	rootCmd.AddCommand(implicitCmd)
}
