package util

import (
	"bufio"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"log"
	"math/rand"
	"os"
	"strings"
	"syscall"
	"time"

	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
	"github.com/spf13/viper"
	"golang.org/x/term"
)

const (
	CODE_LENGTH = 32
)

// Initialize the configuration file.
func InitConfig() {
	viper.AddConfigPath(".")
	viper.SetConfigName("app")
	viper.SetConfigType("env")

	viper.AutomaticEnv()

	if err := viper.ReadInConfig(); err == nil {
		fmt.Println("Using configuration file: ", viper.ConfigFileUsed())
	}
}

// Set configuration values to the flags if they're not provided.
func SetCommandValues(cmd *cobra.Command) {
	// Set local flag values.
	cmd.Flags().VisitAll(func(f *pflag.Flag) {
		// Environment variables can't have dashes in them,
		// so bind them to their equivalent keys with underscores,
		// e.g. --authorize-endpoint to authorize_endpoint
		envVarSuffix := ""
		if strings.Contains(f.Name, "-") {
			envVarSuffix = strings.ReplaceAll(f.Name, "-", "_")
			viper.BindEnv(f.Name, envVarSuffix)
		}

		// Apply the viper config value to the flag
		// when the flag is not set and viper has a value
		if !f.Changed && viper.GetString(envVarSuffix) != "" {
			val := viper.GetString(envVarSuffix)
			cmd.Flags().Set(f.Name, fmt.Sprintf("%v", val))
		}
	})
}

// Prompt for application creation confirmation.
func PromptAppCreation() {
	fmt.Print("You need to create an OAuth 2.0 service provider(application) with this grant type enabled in your IDP, to test this flow.\nType `continue` once you've created the application : ")
	var done string
	n, err := fmt.Scanln(&done)
	if err != nil {
		log.Fatalln(err)
	}
	if n != 1 && strings.EqualFold("continue", done) {
		panic("Invalid input from user.")
	}
}

// Prompt for client ID of the application.
func PromptForClientId() string {
	fmt.Print("Enter the client ID of the application : ")
	var clientId string
	n, err := fmt.Scanln(&clientId)
	if err != nil {
		log.Fatalln(err)
	}
	if n != 1 && len(strings.TrimSpace(clientId)) == 0 {
		panic("Invalid input from user as the client ID.")
	}
	return clientId
}

// Prompt for client secret of the application.
func PromptForClientSecret() string {
	fmt.Print("Enter the client secret of the application : ")
	byteSecret, err := term.ReadPassword(int(syscall.Stdin))
	// New line for next input.
	fmt.Println()
	if err != nil {
		log.Fatalln(err)
	}
	if len(byteSecret) < 1 {
		panic("Invalid client secret provided.")
	}
	clientSecret := string(byteSecret)
	return clientSecret
}

// Prompt for the callback URL of the application.
func PromptForCallbackURL() string {
	fmt.Print("Enter redirect URL(ie. Callback URL) of the application : ")
	var callBackURL string
	n, err := fmt.Scanln(&callBackURL)
	if err != nil {
		log.Fatalln(err)
	}
	if n != 1 && len(strings.TrimSpace(callBackURL)) == 0 {
		panic("Invalid input from user as the callback URL.")
	}
	return callBackURL
}

// Prompt for requested scopes.
func PromptForScopes() string {
	fmt.Print("Enter required scopes separated by spaces(ie. email <test_scope>) : ")
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
	err := scanner.Err()
	if err != nil {
		log.Fatalln(err)
	}
	scopes := scanner.Text()
	return scopes
}

// Prompt for the identifier(ie. audience) of the API.
func PromptForAudience() string {
	fmt.Print("Enter the identifier(ie. audience) of the API : ")
	var audience string
	n, err := fmt.Scanln(&audience)
	if err != nil {
		log.Fatalln(err)
	}
	if n != 1 && len(strings.TrimSpace(audience)) == 0 {
		panic("Invalid input from user as the API audience.")
	}
	return audience
}

// Prompt for the refresh token.
func PromptForRefreshToken() string {
	fmt.Print("Enter the obtained refresh token : ")
	var refreshToken string
	n, err := fmt.Scanln(&refreshToken)
	if err != nil {
		log.Fatalln(err)
	}
	if n != 1 && len(strings.TrimSpace(refreshToken)) == 0 {
		panic("Invalid input from user as the refresh token.")
	}
	return refreshToken
}

func PromptForUsername() string {
	fmt.Print("Enter the username of the user : ")
	var username string
	n, err := fmt.Scanln(&username)
	if err != nil {
		log.Fatalln(err)
	}
	if n != 1 && len(strings.TrimSpace(username)) == 0 {
		panic("Invalid input from user as the refresh token.")
	}
	return username
}

func PromptForPassword() string {
	fmt.Print("Enter the password of the user : ")
	byteSecret, err := term.ReadPassword(int(syscall.Stdin))
	if err != nil {
		log.Fatalln(err)
	}
	if len(byteSecret) < 1 {
		panic("Invalid password provided.")
	}
	password := string(byteSecret)
	return password
}

// Generate PKCE code verifier. Length of the code verifier is 32.
func CodeVerifier() string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	b := make([]byte, CODE_LENGTH)
	for i := 0; i < CODE_LENGTH; i++ {
		b[i] = byte(r.Intn(255))
	}
	return base64URLEncode(b)
}

// Generate PKCE code challenge. Code challenge is generated using the code verifier.
func CodeChallengeS256(codeVerifier string) string {
	h := sha256.New()
	h.Write([]byte(codeVerifier))
	return base64URLEncode(h.Sum(nil))
}

// Encode the given string to base64 URL encoding.
func base64URLEncode(str []byte) string {
	encoded := base64.StdEncoding.EncodeToString(str)
	encoded = strings.Replace(encoded, "+", "-", -1)
	encoded = strings.Replace(encoded, "/", "_", -1)
	encoded = strings.Replace(encoded, "=", "", -1)
	return encoded
}
