package main

import "github.com/cybere2e/oauth2-grant-flow-tester/cmd"

func main() {
	cmd.Execute()
}
